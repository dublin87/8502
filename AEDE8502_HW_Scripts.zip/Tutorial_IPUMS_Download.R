#######################################################################################################################
##### AEDE7415HW: IPUMS Download File
##### 26 January 2020
##### Description: This script downloads the metadata and the 2017 TIGER shapefiles for US counties, US census tracts,
#####              and US block groups from IPUMS NHGIS
#######################################################################################################################

#######################################################################################################################
### Gather Metadata from IPUMS
### Note: Here we request the metadata for the shapefiles that IPUMS has available to us. This will allow us to get the
###       names of the files and request these for download. We need to POST the request to the server and wait until
###       it is ready, then GET the download link and unzip it into our data folder.
### Note: This first chunk is the part that if you were trying to turn this into a plug and play function for your own work, 
###       you'd need to change. The IPUMS metadata allows you to identify the naming structure of their shapefiles, 
###       you could specify the inputs of your function to be each part of the naming structure. For example, take a look
###       at the metadata in ipums_md; you get something like "geography"_"extent"_"Year"_"basis". Email me and I can give 
###       you that function. 
#######################################################################################################################

### Note: Specify the url that we will be requesting at
ipums_url <- "https://api.ipums.org/metadata/nhgis/shapefiles?version=v1"

### Note: Create a GET request for the shapefile metadata; we are adding a header to our GET request that includes our 
  #       authorization key. The response from the server is stored in a list. You can open this and examine it if you choose;
  #       we are only interested in the content portion of the response in the body. We use the content function to translate
  #       this from unicode to JSON, or parse it into a data frame from JSON. We end up w/ all the shapefiles we can 
  #       request from IPUMS stored in a data matrix called a data frame. 

ipums_md  <- GET(ipums_url, add_headers(Authorization = auth_key))
ipums_md  <- content(ipums_md, "parsed", simplifyDataFrame = TRUE)


### Note: We are interested in the 2010 census shapefiles for Ohio. I use "pipes" to conduct a set of operations to filter
  #       the metadata data frame. Double equals signs for true/false conditions
ipums_md_sort <- ipums_md                      %>%
  filter(year == 2014)                         %>%
  filter(geographic_level == "Block Group"  | 
         geographic_level == "Census Tract" |
         geographic_level == "County"       |
         geographic_level == "Metropolitan Statistical Area/Micropolitan Statistical Area")

### Note: It looks like there exists a state-specific file for Block groups, but not for census tracts or 
  #       counties. We will filter further to get our three shapefiles; I create two different data frames 
  #       and merge them back together using bind_rows from the tidyverse

ipums_md_sort1 <- ipums_md_sort %>%
  filter(geographic_level == "Block Group" & extent == "Ohio")
ipums_md_sort2 <- ipums_md_sort %>%
  filter(extent == "United States" & geographic_level != "Block Group")
ipums_md_sort  <- bind_rows(ipums_md_sort1, ipums_md_sort2)

### Note: Now let's capture the names of each of the shapefiles we want as well as their geographic levels
  #       so we can post our data request to IPUMS. Note that double parenthesis creates a vector from the 
  #       name of the variable/column I request
ipums_names  <- ipums_md_sort[["name"]]

#######################################################################################################################
### Post data request to IPUMS
#######################################################################################################################

### Note: We will now use our shapefiles names and and extents to create a POST request to IPUMS; IPUMS will then work
  #       to create our request. Note that this will not occur instantaneously. We will have to request status updates
  #       and download the data when those status requests tell us the data is ready. You'll also receive an email telling
  #       you when your download is ready. 

ipums_url <- "https://api.ipums.org/extracts/?product=nhgis&version=v1"
print(ipums_names)

### Note: Create some JSON that will be in the body of our post request to the url above; developer portals will 
  #       typically describe how to structure your requests. See the IPUMS portal for examples. You'll need to mess
  #       around w/ the JSON to make this work w/ non shapefiles. 
post_body <- '

{
  "shapefiles": [
    "390_blck_grp_2014_tl2014",
    "us_county_2014_tl2014",
    "us_tract_2014_tl2014",
    "us_cbsa_2014_tl2014"
  ],
  "description": "AEDE7415 Homework Shapefiles"
}

'
post_descr <- "AEDE7415 Homework Shapefiles"
post_body <- list(shapefiles  = ipums_names,
                  description = post_descr) 
ipums_post   <- POST(ipums_url, add_headers(Authorization = auth_key), body = post_body, encode = "json")
ipums_df     <- content(ipums_post, "parsed", simplifyDataFrame = TRUE)


print(ipums_post$status_code) # this should be 200 if it worked
ipums_extnum <- ipums_df$number   #Note that you can navigate through items in your list (or data frame) with a dollar sign  

#######################################################################################################################
### Check status of request until ready
#######################################################################################################################

### Note: We are waiting for our request to be ready, then we want to extract. We can request the status of our request
  #       over and over again until it is ready, but this may lead to us exceeding our limit on how many requests we can
  #       make with our API key. Therefore, we can create a loop that runs a GET request on our status, waits a period of time, 
  #       then repeats until our data is ready

### Note: We update the URL to request our extract number from above
ipums_url <- paste0("https://api.ipums.org/extracts/", ipums_extnum, "?product=nhgis&version=v1")

### Note: create a while loop that checks the status of our request every 15 seconds until the status of our request is 
  #       complete. We move to the next chunk of code once the control loop is passed. 
request_vec <- "NA"
while(request_vec != "completed"){
  Sys.sleep(15)
  ipums_get   <- GET(ipums_url, add_headers(Authorization = auth_key))
  ipums_get   <- content(ipums_get, "parsed", simplifyDataFrame = TRUE)
  request_vec <- ipums_get$status
}

### Note: We now grab the download links that come w/ our response from IPUMS and download our files
ipums_links <- ipums_get$download_links[[1]]
for (i in ipums_links){
  download.file(i, paste0(file_downloads, "\\IPUMS_shapefiles.zip"), 
                headers = c(Authorization = auth_key))
}

### Note: Check your downloads folder and you'll find your shapefiles; let's extract them
  #       Step 1: Pad our request number from above to fit the name of the download (e.g. 0001). We can use the string pad 
  #               str_pad function to do this; this function adds the appropriate amount of characters of some time to make 
  #               a string a given length. SUPER useful when dealing w/ FIPS codes. 
  #       Step 2: For some reason, the file comes in two layers of zips; first we unzip the full download into our downloads
  #       Step 3: Here we can take advantage of the excellent list.files function; this lists all the files in a given directory
  #               that we then use in a loop to unzip all files.

ipums_extnum <- str_pad(ipums_extnum, 4, side = "left", pad = "0")
tempzip      <- paste0(file_downloads, "\\IPUMS_shapefiles.zip")
unzip(tempzip, exdir = file_downloads)

ziplist <- list.files(paste0(file_downloads, "\\nhgis", ipums_extnum, "_shape"), full.names = TRUE)
for (i in ziplist){
  unzip(i, exdir = here("Data", "Shapefiles_raw"))
}

### Note: Remove the stuff we don't need
vardrop <- c("ipums_get", "ipums_md", "ipums_md_sort", "ipums_md_sort1", "ipums_md_sort2",
             "ipums_post", "post_JSON")
rm(list=ls()[ls() %in% vardrop])