#######################################################################################################################
##### AEDE7415HW: Census FTP Cleaning
##### 26 January 2020
##### Description: This script cleans the data downloaded from the census FTP site on primary and secondary roadways
#######################################################################################################################

### Note: we are listing the files in our download folder, and then filtering them to get only the shapefiles
roadlist <- list.files(here("Data", "Shapefiles_raw", "Roads"), pattern = ".shp$")
namelist <- str_sub(roadlist, end = str_locate(roadlist, "\\.")[,2]-1)

### Note: Import the data
for (i in 1:length(roadlist)){
  tempname <- str_sub(roadlist[i], end = str_locate(roadlist[i], "\\.")[1,1]-1)
  tempdata <- st_read(here("Data", "Shapefiles_raw", "Roads", roadlist[i]), 
                      stringsAsFactors = FALSE)
  assign(tempname, tempdata)
}

### Note: Merge all files (if need be) into one file
n <- length(namelist)
prisec_roads_full <- get(namelist[1])
if (n > 1){
  for (i in 2:n){
    tempdata          <- get(namelist[i])
    prisec_roads_full <- bind_rows(prisec_roads_full, tempdata)
  }
}


### Note: Clean up the roadway data
keepvec <- c("RoadID", "StreetName", "StreetType")
prisec_roads_full <- prisec_roads_full   %>%
  rename("RoadID"     = LINEARID,
         "StreetName" = FULLNAME,
         "StreetType" = MTFCC)            %>%
  select(one_of(keepvec))
prisec_roads_full$StreetType[prisec_roads_full$StreetType=="S1100"] <- "Primary Road"
prisec_roads_full$StreetType[prisec_roads_full$StreetType=="S1200"] <- "Secondary Road"


### Note: Slice out the sections of the road network we need using st_intersection. MAKE SURE THE PROJECTIONS
  #       ARE THE SAME
proj <- st_crs(countyshape)
cbsa <- st_union(countyshape)
prisec_roads_full  <- st_transform(prisec_roads_full, proj)
prisec_roads_final <- st_intersection(prisec_roads_full, cbsa)


### Note: Write the shapefile into our folder
st_write(prisec_roads_final, here("Data", "Shapefiles", "Census_TIGER2014_PriSecRoads.shp"), 
         delete_dsn = TRUE)

### Note: Remove unnecessary variables
rm(list=ls()[ls() %in% c(namelist, "tempdata", "prisec_roads_full", "proj", "cbsa")])
