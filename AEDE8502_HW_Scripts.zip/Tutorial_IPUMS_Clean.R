#######################################################################################################################
##### AEDE7415HW: IPUMS Cleaning File
##### 26 January 2020
##### Description: This script cleans the downloaded county, census block group, and census tract shapefiles and selects
#####              the portions we need for our analysis. This is a good script to familiarize yourself with the SF package.
#####              We will be using the sf package to read in data and to check projection types.
#######################################################################################################################

### Note: Read in our shapefiles from the data file. We use the function st_read from sf and specify that we don't want
  #       character vectors to be factorized. Take a look at these shapefile data frames; there is a column called 
  #       geometry. This is where the details of the shape are stored. Keep in mind projection systems; we can check 
  #       that using st_crs, which extracts the coordinate reference system used for the data. MAKE SURE YOUR COORDINATE
  #       REFERENCE SYSTEMS ARE THE SAME ACROSS ALL SHAPEFILES

shapeloc        <- here("Data", "Shapefiles_raw")
raw_cbsashape   <- st_read(paste0(shapeloc, "\\US_cbsa_2014.shp"), stringsAsFactors = FALSE)
raw_countyshape <- st_read(paste0(shapeloc, "\\US_county_2014.shp"), stringsAsFactors = FALSE)
raw_ctshape     <- st_read(paste0(shapeloc, "\\US_tract_2014.shp"), stringsAsFactors = FALSE)
raw_cbgshape    <- st_read(paste0(shapeloc, "\\OH_blck_grp_2014.shp"), stringsAsFactors = FALSE)

### Note: Lets check our coordinate reference systems
if (st_crs(raw_cbsashape) == st_crs(raw_countyshape) & 
    st_crs(raw_cbsashape) == st_crs(raw_ctshape) &
    st_crs(raw_cbsashape) == st_crs(raw_cbgshape)){
  print("All CRS are equal")
}else{
  print("Change your CRS")
}


### Note: Assume we don't know the CBSA ID for Columbus; let's use the CBSA shapefile to grab it and turn it into a
  #       character value. Note the function st_geometry here: Set the geometry to null to turn this into a regular 
  #       old data frame instead of a simple feature
col_cbsa <- raw_cbsashape                    %>%
  filter(str_detect(NAME, "Columbus, OH"))

st_geometry(col_cbsa) <- NULL
col_cbsa <- col_cbsa[["CBSAFP"]]
print(col_cbsa)

  
### Note: Now we can use the county shapefile to grab the counties we need; this includes an indicator for the CBSA 
  #       the county is in. In this case, we want to keep the shapes associated w/ the counties we filter. Note the use
  #       of the select function which picks the variables we want. We will also grab a vector of our selected counties
  #       for use later on.
varkeep_county <- c("ContyID", "ContyNm", "CBSAID", "LndAr_s")
countyshape    <- raw_countyshape        %>%
  filter(CBSAFP == col_cbsa)             %>%
  mutate(ContyID = GEOID,
         ALAND = round(ALAND/1000000,3)) %>%
  rename("ContyNm" = NAME,
         "CBSAID" = CBSAFP,
         "LndAr_s" = ALAND)        %>%
  select(one_of(varkeep_county))
countykeep <- countyshape[["ContyID"]]


### Note: Next, we filter the tract and blockgroup shapefiles to make them a bit more tractable; we are filtering only those
  #       counties in our countykeep vector
varkeep_tract <- c("TractID", "ContyID", "LndAr_s")
ctshape       <- raw_ctshape                  %>%
  mutate(ContyID = str_c(STATEFP, COUNTYFP),
         TractID = GEOID,
         ALAND = round(ALAND/1000000,3))      %>%
  rename("LndAr_s" = ALAND)             %>%
  filter(ContyID %in% countykeep)            %>%
  select(one_of(varkeep_tract))


varkeep_bg <- c("BGID", "ContyID", "LndAr_s")
cbgshape   <- raw_cbgshape                    %>%
  mutate(ContyID = str_c(STATEFP, COUNTYFP),
         BGID = GEOID,
         ALAND = round(ALAND/1000000,3))      %>%
  rename("LndAr_s" = ALAND)             %>%
  filter(ContyID %in% countykeep)            %>%
  select(one_of(varkeep_bg))


### Note: Write our administrative region shapefiles
st_write(countyshape, here("Data", "Shapefiles", "NHGIS_TIGER2014_County.shp"), delete_dsn = TRUE)
st_write(ctshape, here("Data", "Shapefiles", "NHGIS_TIGER2014_CensusTract.shp"), delete_dsn = TRUE)
st_write(cbgshape, here("Data", "Shapefiles", "NHGIS_TIGER2014_CensusBlockGroup.shp"), delete_dsn = TRUE)


### Note: Delete the raw files to save some space
droplist <- c("raw_cbsashape", "raw_cbgshape", "raw_countyshape", "raw_ctshape")
rm(list=ls()[ls() %in% droplist])
