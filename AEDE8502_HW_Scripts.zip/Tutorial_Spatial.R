#######################################################################################################################
##### AEDE7415HW: Tutorial Scripts: Shapefile stuff
##### 26 January 2020
##### Description: This script creates a shapefile using our sales data and then shows some of the sf functions and what
#####              they do
#######################################################################################################################

### Note: We use the readr package in the tidyverse to read in the sales data stored in the csv file. We want to make this
  #       into a shapefile so we can do our spatial operations. We can use st_as_sf from the sf package. 

sales      <- read_csv(here("Data", "Sales", "ResidentialSales_ColumbusMSA_2010-2014.csv"))
salesshape <- st_as_sf(sales, coords = c("Longitude", "Latitude"))

### Note: We need to assign our shapefile a coordinate reference system. We use NAD83; you can look up different spatial 
  #       reference systems at spatialreference.org. For simplicity, we will change this to match our census shapefiles.
  #       4269 is the EPSG code for the NAD83 coordinate reference system. 
st_crs(salesshape) <- 4269
proj <- st_crs(countyshape)
salesshape <- st_transform(salesshape, proj)

test <- st_intersection(salesshape, countyshape)
test <- test %>%
  mutate(test1 = if_else(CountyID == ContyID, 1, 0)) %>%
  group_by(test1)                                    %>%
  summarise(count = n())

### Note: Lets use ggplot to plot out our sales for 2014; you can adjust your maps w/ a bunch of different ggplot settings. See the 
  #       cheatsheets and the tidyverse explainer page for plot examples
testdata <- salesshape %>%
  filter(SaleDate_Year == 2014)


ggplot() +
  geom_sf(data = countyshape) +
  geom_sf(data = testdata, aes(color = PropType)) +
  geom_sf(data = prisec_roads_final) +
  geom_sf_label(data = countyshape, aes(label = ContyNm))
  

### Note: After plotting our observations, it seems like there are a few sales that are outside the boundaries. Let's identify
  #       those transactions outside of the CBSA and remove them. I first "dissolve" the features of the county shapefile into one feature 
  #       (this is effectively a shapefile of the cbsa w/ just columbus selected). I then remove salesshape to save some space

cbsashape    <- st_union(countyshape)
plot(cbsashape)

testdata_1 <- st_intersection(testdata, cbsashape)
rm(list=ls()[ls() %in% c("testdata")]) 

### Note: Suppose we wanted to figure out which sales are close to county boundaries; we can generate county level buffer regions (cough) and
  #       intersect the sales and buffer shapefiles. Note that I'm setting this boundary to be 1 km in size. I can intersect the county boundary
  #       buffer with itself to get at which boundaries correspond to which (e.g the Franklin county Delaware county border zone, a dangerous zone of lawlessness
  #       and savagery)
countyboundaries <- st_boundary(countyshape)
countyboundbuff  <- st_buffer(countyboundaries, 1000)
plot(countyboundbuff$geometry)

# Note: I can intersect the county boundary buffer with itself to get at which boundaries correspond to which (
#       e.g the Franklin county Delaware county border zone, a dangerous zone of lawlessness and savagery)
countyboundbuff2 <- st_intersection(countyboundbuff, countyboundbuff) %>%
  mutate(BufferZone = if_else(ContyID == ContyID.1, ContyNm, str_c(ContyNm, "/", ContyNm.1))) %>%
  select(one_of("BufferZone"))

testdata_2 <- st_intersection(testdata_1, countyboundbuff2)
plot(testdata_2)

### Note: Suppose we wanted to create a highway network shapefile w/ two features, one for primary roads and one for secondary roads
newroads <- prisec_roads_final %>%
  group_by(StreetType) %>%
  summarise()

### Note: Suppose we wanted to get the exact distance (cough) between the sales locations and the nearest secondary road. The output is a matrix of
  #       distances between objects (in this case, its a vector since "newroads" contains only 1 feature)
secondary <- newroads %>%
  filter(StreetType == "Secondary Road")
distances <- st_distance(testdata_2, secondary)

testdata_3 <- testdata_2 %>%
  mutate(DistToSec = as.numeric(distances))

### Note: lets write some finished spatial data to export it; note the warnings!!!! there are limits on how wide fields can be in the
  #       shapefile format. Nullify the geometry and export your data to csv and reconvert your points back into lat/long columns. I would
  #       also recommend reprojecting your data to a coordinate reference system expressed in decimal degrees
st_write(testdata_3, here("Output", "Testdata.shp"))


testdata_4 <- st_transform(testdata_3, 4269) %>%
  mutate(Longitude = st_coordinates(geometry)[,1],
         Latitude = st_coordinates(geometry)[,2])
st_geometry(testdata_4) <- NULL
print(testdata_4$Latitude[1], digits = 10)

write_csv(testdata_4, here("Output", "Testdata.csv"))

### Note: flip the table over and quit playing
# rm(list=ls())
