#######################################################################################################################
##### AEDE7415HW: IPUMS Download File
##### 26 January 2020
##### Description: This script downloads data directly from the US Census FTP site using the rvest package
#######################################################################################################################

### Note: We will use the web scraping capabilities of rvest to parse the html from a download website and extract the 
  #       download links we want to use. You can navigate to www2.census.gov/geo/tiger/TIGER2010 to examine the 
  #       available shapefiles from the census. 

cen_url <- "https://www2.census.gov/geo/tiger/TIGER2014/PRISECROADS/"

### Note: Step 1 -- Read in the html from the url above into a list (that stores the html in a node-like structure)
  #       Step 2 -- Identify the type of nodes we want to filter (I highly recommend using SelectorGadget to identify
  #                 the CSS selector you want to use here).
  #       Step 3 -- extract the href attribute from the td a nodes (this is our download link)
  #       Step 4 -- Turn the selected attributes into a data frame so we can look at it and use tidyverse commands to
  #                 manipulate it
cen_html       <- read_html(cen_url) %>%
  html_nodes("td a")                 %>%
  html_attr("href")                  %>%
  data.frame()                      

### Note: if you open cen_html, you'll see one variable with a bunch of zipped files (with the first row being the 
  #       parent directory and not an actual download link). By inspecting one of the download links on the website
  #       we can see the full link; we just need to paste the url above w/ the zipped file link. The files are named
  #       by their State FIPS code; in this case, we only need to download one link.
### Note: So now, we need to filter just for zipped folders.  We will then create the full download links by pasting 
  #       the full url to the names of the zipped folders
cen_html_test <- cen_html
cen_html_test <- cen_html_test                       %>%
  filter(str_detect(., ".zip"))                      %>%
  mutate(StateID = str_sub(., start = 9, end = 10),
         DownloadLink = paste0(cen_url, .))          %>%
  filter(StateID == 39)

name_vec <- as.character(cen_html_test[["."]])
dl_vec   <- cen_html_test[["DownloadLink"]]

for (i in 1:length(dl_vec)){
  download.file(dl_vec[i], paste0(file_downloads, "\\", name_vec[i]))
}

### Note: Extract the road shapefiles from the zipped downloads
for (i in 1:length(name_vec)){
  unzip(paste0(file_downloads, "\\", name_vec[i]), exdir = here("Data", "Shapefiles_raw", "Roads"))
}

### Note: Remove unnecessary files
rm(list=ls()[ls() %in% c("cen_html", "cen_html_list", "cen_html_test")])
